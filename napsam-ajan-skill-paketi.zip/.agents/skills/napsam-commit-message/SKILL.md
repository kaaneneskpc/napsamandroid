---
name: napsam-commit-message
description: Commit mesajı önerirken kullan. Sadece metin üretir, git komutu çalıştırmaz.
---

# Kalıp (git log'dan)
`<Alan>: <ne yapıldı>` · Alan: `Faz N`, `Duzeltme`, `Spec C11`, `CI`, `Plan`, `Performans`, `README`.
Başlık Türkçe karakter kullanmadan yazılır, ör. `Duzeltme: "Yaz" modunda metin gonderince uygulama cokuyordu`.
Gövde: neden, kök neden, nasıl doğrulandı.

# Commit'ten önce ENGEL
- Diff'te anahtar ya da token, keystore, local.properties, build/ klasörü.
- contract/ değişmişse kaynağı web'deki export mu?
- Golden değişmişse farkı insan gördü mü?
