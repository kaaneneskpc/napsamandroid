---
name: napsam-local-repro
description: Bir hatayı cihazda ya da emülatörde yeniden üretmek gerektiğinde kullan.
---

# Cihazda görmeden düzeltme tahmindir
- Süreç ölümü: `adb shell am kill com.kaaneneskpc.napsam`, sonra
  `adb shell monkey -p com.kaaneneskpc.napsam -c android.intent.category.LAUNCHER 1`.
- %200 yazı: `adb shell settings put system font_scale 2.0` (sonra 1.0).
- Koyu tema: `adb shell cmd uimode night yes`.
- İnternetsiz: uçak modunda soğuk açılış; kart yine gelmeli.
- R8'li sürüm: `./gradlew :app:installRelease` yoksa assembleRelease + adb install.
- Emülatör: Pixel_9_Pro_API_37 (B20).
