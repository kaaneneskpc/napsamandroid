---
name: napsam-ui-defect-map
description: Görsel bir hatayı (taşma, kontrast, kayma, yanlış yerde kaydırma) mekanizmasına bağlamak için kullan.
---

# Önce dört soru
Tema (açık/koyu) · Yazı ölçeği · Ekran genişliği (geniş ekranda içerik 760 dp ortalanır) · Akış (ilk açılış, Başka fikir, geri dönüş)

# Semptom → mekanizma
- %200 yazıda kesilen düğme → sabit yükseklik; `heightIn(min = 48.dp)` ve sarma.
- Koyu temada okunmayan metin → token yanlış yüzeyde; ColorContrastTest'e bak.
- "Başka fikir"den sonra kartın başı görünmüyor → `stageScrollRequest` artmıyor (web'de yaşanmış hata, regresyon testi var).
- En uzun Türkçe metin taşıyor → anasayfa_en_uzun_oneri_kayitli_mesajli golden'ı.

# Kural
Düzeltmeyi dar tut; ortak bir bileşene dokunacaksan önce etkiyi yaz ve sor.
