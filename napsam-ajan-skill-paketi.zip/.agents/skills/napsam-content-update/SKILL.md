---
name: napsam-content-update
description: Öneri içeriği, contract/ ya da içerik güncelleme akışı konuşulduğunda kullan.
---

# İçerik nereden gelir?
Tek kaynak web reposundaki `core/fixtures/suggestions.json`. `export_mobile` komutu içeriği ve parite vakalarını contract/ altına yazar.

1. contract/ elle düzenlenmez (B19). Değişiklik web'de yapılır, yeniden dışa aktarılır.
2. Uygulama: ilk açılışta gömülü içerik Room'a aktarılır; sürüm değişince `GET /api/v1/content/` indirilir.
3. ContentImporter doğrular: boş değil, beklenen sayı, yinelenen slug yok, şema. Geçmeyen içerik yazılmaz.
4. Geçen içerik tek transaction'da değişir; kullanıcının kayıtları korunur.
