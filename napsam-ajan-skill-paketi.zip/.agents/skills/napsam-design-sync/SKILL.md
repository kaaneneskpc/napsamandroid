---
name: napsam-design-sync
description: Tasarımdan token ya da bileşen taşırken kullan; stitch-designer ajanının tarif kitabı.
---

# Tasarımdan koda
Kaynak: docs/design/mobile-light.html, mobile-dark.html ve DESIGN.md.

1. Renk → Color.kt (`NapsamColors`, açık ve koyu), yazı → Type.kt, ölçü → Dimensions.kt.
2. Yorumda Tailwind sınıfı: `accent = Color(0xFFEA580C) // orange-600`.
3. Karşılığı olmayan değeri ekleme; öner.
4. Status bar ve üst bar kabuktan gelir; ekranda yeniden çizme.
5. Doğrula: ColorContrastTest, Roborazzi; tasarım istisnaları testte belgelenir.
