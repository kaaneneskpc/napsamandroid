---
name: napsam-build-verify
description: 'Derleniyor mu, testler geçiyor mu?' sorusunda ve bir işi bitirmeden önce kullan.
---

# Doğru doğrulama
1. Değişen dosyalardan modülleri çıkar: `git diff --name-only main... | cut -d/ -f1-2 | sort -u`.
2. Modül başına: `./gradlew :<modül>:testDebugUnitTest` (saf Kotlin modüllerde `:<modül>:test`).
3. UI değiştiyse: `:<modül>:verifyRoborazziDebug`. Motor değiştiyse: parite testleri.
4. Bitirmeden önce CI ile aynı komut: `./gradlew check verifyRoborazziDebug`.
5. Sonucu metinden değil exit code'dan oku. Pipe kullanıyorsan `$?` son komutun kodudur; `set -o pipefail` ya da `${PIPESTATUS[0]}`.
6. JDK'yı Gradle seçer (gradle/gradle-daemon-jvm.properties, JDK 21).
