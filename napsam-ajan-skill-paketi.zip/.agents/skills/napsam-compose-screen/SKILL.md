---
name: napsam-compose-screen
description: Yeni bir ekran, bileşen ya da UiState eklerken kullan.
---

# napsam'da ekran kurmak
Referans: feature/home (HomeScreen.kt, HomeViewModel.kt, HomeUiState.kt).

1. Ekran = stateful `XScreen(viewModel)` + stateless `XContent(state, onEvent)`.
2. Tek `UiState` (@Immutable, ImmutableList); ViewModel'i alt composable'lara geçirme (B19).
3. `collectAsStateWithLifecycle()` sadece en üstte; `collectAsState()` yasak.
4. Metin strings.xml'de, çoğul `plurals` ile; renk ve ölçü core:designsystem'dan.
5. Kaydırma isteği gibi tek seferlik işler state'te sayaçla (`stageScrollRequest`).
6. Her ekranda: açık/koyu ve %200 yazı golden'ı (Roborazzi).
